/* ============================================
   BuildCalcTools — main.js  v2
   Navbar + footer injection, mobile menu,
   lazy images, scroll animations
   ============================================ */

const NAV_HTML = `
<nav class="navbar">
  <div class="container navbar-inner">
    <a href="/index.html" class="nav-logo">
      <div class="nav-logo-icon">
        <svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.2"
             stroke-linecap="round" stroke-linejoin="round" width="20" height="20">
          <rect x="4" y="2" width="16" height="20" rx="2"/>
          <line x1="8" y1="7"  x2="16" y2="7"/>
          <line x1="8" y1="11" x2="16" y2="11"/>
          <line x1="8" y1="15" x2="13" y2="15"/>
        </svg>
      </div>
      <span class="nav-logo-text">BUILD<span>CALC</span>TOOLS</span>
    </a>
    <div class="nav-links" id="navLinks">
      <a href="/index.html">Home</a>
      <a href="/tools/index.html">Calculators</a>
      <a href="/blog/index.html">Blog</a>
      <a href="/about.html">About</a>
    </div>
    <button class="nav-hamburger" id="navToggle" aria-label="Toggle navigation">
      <span></span><span></span><span></span>
    </button>
  </div>
</nav>`;

const FOOTER_HTML = `
<footer class="footer">
  <div class="container">
    <div class="footer-top">
      <div class="footer-brand">
        <a href="/index.html" class="nav-logo" style="margin-bottom:12px;display:inline-flex;">
          <div class="nav-logo-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.2"
                 stroke-linecap="round" stroke-linejoin="round" width="20" height="20">
              <rect x="4" y="2" width="16" height="20" rx="2"/>
              <line x1="8" y1="7"  x2="16" y2="7"/>
              <line x1="8" y1="11" x2="16" y2="11"/>
              <line x1="8" y1="15" x2="13" y2="15"/>
            </svg>
          </div>
          <span class="nav-logo-text">BUILD<span>CALC</span>TOOLS</span>
        </a>
        <p>Free construction calculators for engineers, contractors and builders. No signup ever required.</p>
      </div>
      <div class="footer-col">
        <div class="footer-links-group">
          <span class="footer-links-title">Calculators</span>
          <a href="/tools/concrete-calculator.html">Concrete Calculator</a>
          <a href="/tools/brick-calculator.html">Brick Calculator</a>
          <a href="/tools/steel-calculator.html">Steel Calculator</a>
          <a href="/tools/index.html">All Tools</a>
        </div>
      </div>
      <div class="footer-col">
        <div class="footer-links-group">
          <span class="footer-links-title">Site</span>
          <a href="/about.html">About</a>
          <a href="/blog/index.html">Blog</a>
          <a href="/contact.html">Contact</a>
        </div>
      </div>
      <div class="footer-col">
        <div class="footer-links-group">
          <span class="footer-links-title">Legal</span>
          <a href="/privacy-policy.html">Privacy Policy</a>
          <a href="/terms.html">Terms of Use</a>
          <a href="/disclaimer.html">Disclaimer</a>
        </div>
      </div>
    </div>
    <div class="footer-bottom">
      <p>© <span id="fyear"></span> BuildCalcTools.site — All rights reserved.</p>
      <span class="footer-free-badge">✦ Free Tool — No Signup Needed</span>
      <p>Built by <a href="/about.html" style="color:var(--color-primary);">Malik Obaid Ur Rehman</a></p>
    </div>
  </div>
</footer>`;

document.addEventListener('DOMContentLoaded', () => {

  /* ── Inject navbar ── */
  const nb = document.getElementById('navbar');
  if (nb) { nb.outerHTML = NAV_HTML; }

  /* ── Inject footer ── */
  const ft = document.getElementById('footer');
  if (ft) { ft.outerHTML = FOOTER_HTML; }

  /* ── Current year ── */
  const yr = document.getElementById('fyear');
  if (yr) yr.textContent = new Date().getFullYear();

  /* ── Active nav highlight ── */
  const path = window.location.pathname;
  document.querySelectorAll('.nav-links a').forEach(a => {
    const href = a.getAttribute('href') || '';
    if (href === '/index.html' && (path === '/' || path === '/index.html')) {
      a.classList.add('active');
    } else if (href !== '/index.html' && href.length > 1 && path.includes(href.replace('/index.html','').replace('.html',''))) {
      a.classList.add('active');
    }
  });

  /* ── Mobile hamburger ── */
  document.addEventListener('click', e => {
    const toggle = document.getElementById('navToggle');
    const links  = document.getElementById('navLinks');
    if (!toggle || !links) return;
    if (toggle.contains(e.target)) {
      links.classList.toggle('open');
      toggle.classList.toggle('is-open');
    } else if (!links.contains(e.target)) {
      links.classList.remove('open');
      toggle.classList.remove('is-open');
    }
  });

  /* ── Lazy image loading ── */
  if ('IntersectionObserver' in window) {
    const imgObs = new IntersectionObserver((entries, o) => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        const img = entry.target;
        if (img.dataset.src) {
          img.src = img.dataset.src;
          img.removeAttribute('data-src');
        }
        img.addEventListener('load',  () => img.classList.add('img-loaded'), { once: true });
        img.addEventListener('error', () => img.style.display = 'none',     { once: true });
        o.unobserve(img);
      });
    }, { rootMargin: '300px 0px' });
    document.querySelectorAll('img[data-src]').forEach(i => imgObs.observe(i));
  } else {
    document.querySelectorAll('img[data-src]').forEach(i => { i.src = i.dataset.src; });
  }

  /* ── Scroll-in animations ── */
  if ('IntersectionObserver' in window) {
    const animObs = new IntersectionObserver((entries, o) => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('anim-visible');
        o.unobserve(entry.target);
      });
    }, { threshold: 0.08 });
    document.querySelectorAll('.anim-up').forEach(el => animObs.observe(el));
  } else {
    document.querySelectorAll('.anim-up').forEach(el => el.classList.add('anim-visible'));
  }

});
